import setuptools

setuptools.setup(
    name='hellow-world',
    version= '0.0.1',
    author= 'andy',
    description= 'prints hello world',
    py_modules= ['hello_world'],
    package_die={'': 'hello-world-package/src'}) #package key is empty for some reason